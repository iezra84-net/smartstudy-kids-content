const feedback = document.getElementById("feedback");
const stars = document.getElementById("stars");
let earned = 0;
let answered = false;

document.querySelectorAll("[data-answer]").forEach((button) => {
  button.addEventListener("click", () => {
    if (answered) {
      feedback.textContent = "Kamu sudah menjawab. Hebat, lanjutkan belajar!";
      return;
    }

    if (button.dataset.answer === "8") {
      feedback.textContent = "Benar sekali! 4 × 2 = 8. Kamu hebat!";
      earned += 1;
      stars.textContent = String(earned);
    } else {
      feedback.textContent = "Belum tepat. Coba ingat: 2 + 2 + 2 + 2.";
    }

    answered = true;
  });
});
